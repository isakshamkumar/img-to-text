# Safety-plus

A chrome extension for finding out malicious url and helping you and others trapped in scam websites .

#Safety Plus - True Phishing Detection

Safety plus is a powerful extension which detects phishing attacks in online banking web sites. It is a rule-based system that analyses the webpage content to identify phishing attacks. PhishDetector has the ability to detect online banking phishing scams quickly with zero false negative alarm.

## Features-

Shows a alert on website wheather its safe or not to check how it works see reference.
If you click on OK then only website will load otherwise it will not share any of your information with the website.
It is most usefull for phising sites

## Single purpose:

The extension analyzes page content to detect phishing attack when user opens the extension's popup page by clicking on the it's icon.

## Permission justification:

The extension reads page content to analyze it when user opens the extension's popup page by clicking on the extension's icon. The extension does not collect, transmit or share user data. It just reads page contents and analyses them to find any suspicious content source.
