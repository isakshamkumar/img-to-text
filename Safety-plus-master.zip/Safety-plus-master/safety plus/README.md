# Safety Plus - True Phishing Detection

Safety plus is a powerful extension which detects phishing attacks in online banking web sites. It is a rule-based system that analyses the webpage content to identify phishing attacks. PhishDetector has the ability to detect online banking phishing scams quickly with zero false negative alarm.

### Single purpose:

The extension analyzes page content to detect phishing attack when user opens the extension's popup page by clicking on the it's icon.

### Permission justification:

The extension reads page content to analyze it when user opens the extension's popup page by clicking on the extension's icon.
The extension does not collect, transmit or share user data. It just reads page contents and analyses them to find any suspicious content source.

## Support

Please report any issues with phishdetector by filing an issue on [issues](https://github.com/prakhar1535/Safety-plus/issues) page.


